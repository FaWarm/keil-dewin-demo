#ifndef __START_WIN_H__
#define __START_WIN_H__
#include "sys.h"









void start_win_Xpos(u16 btn_val,u16 muliple);
void start_win_Xvel(u16 btn_val,u16 muliple);



#endif

