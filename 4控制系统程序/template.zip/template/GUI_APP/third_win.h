#ifndef __THIRD_WIN_H__
#define __THIRD_WIN_H__
#include "sys.h"









void third_win_Zpos(u16 btn_val3,u16 muliple);
void third_win_Zvel(u16 btn_val3,u16 muliple);



#endif

