#ifndef __SECOND_WIN_H__
#define __SECOND_WIN_H__
#include "sys.h"









void second_win_Ypos(u16 btn_val2,u16 muliple);
void second_win_Yvel(u16 btn_val2,u16 muliple);



#endif

