#ifndef __FOURTH_WIN_H__
#define __FOURTH_WIN_H__
#include "sys.h"









void fourth_win_wheelvel(u16 btn_val4,u16 muliple);



#endif

