#ifndef __FUNC_HANDLER_H__
#define __FUNC_HANDLER_H__
#include "sys.h"







void btn_click_tick(void);
void btn_click_handler1(void);
void btn_click_handler2(void);
void btn_click_handler3(void);
void btn_click_handler4(void);


#endif
